//postgres://someuser:somepassword@somehost:381/somedatabase

exports.addressesValues = async (req, reply) => {
  try {
    fastify.register(require('fastify-postgres'), {
      connectionString:
        'postgres://postgres:mysecretpassword@localhost:5432/backendnb'
    });
    fastify.pg.query(
      'SELECT * FROM addresses WHERE addressid=$1',
      [req.params.addressId],
      function onResult(err, result) {
        reply.send(result);
      }
    );
  } catch (err) {
    reply.send(err);
  }
};
