const axios = require('axios');

exports.getValues = async (req, reply) => {
  try {
    const data = valuesFromApi(req.params.addressId);
    reply.send(dataToSend(data));
  } catch (err) {
    console.error('Error en el handler address', err);
  }
};

function valuesFromApi(address) {
  return axios.get(
    `https://cardanoexplorer.com/api/addresses/summary/${address}`
  );
}

function dataToSend(balance, transactionCount) {
  return {
    balance: balance,
    transactionCount: transactionCount
  }
}

/*
function valuesAddresses(addressId) {
  if (isAddressStored(addressId)) {
    addressesFromDB(addressId)
   } else {
      const data = addressFromApi(addressId);
      //storeDataOnDB(data);
      return data
   }
}

function isAddressStored(addressId) {
  return //search query with addressId
}

function addressesFromDB(addressId) {
  //select query && build json with data
  const data = searchAddressesOnDB(addressId);
  return dataToSend(data.balance, data.transactionCount);
}

function searchAddressesOnDB(addressId) {

}

function addressFromApi(addressId) {
  const { data } = await valuesFromApi(addressId);
  return dataToSend(data.Right.caBalance.getCoin, data.Right.caTxNum);
}

function addressesFromDB(addressId) {

}

*/
//http://:3000/address?addressId=DdzFFzCqrhsn2LJ5fE8kqtQt1RH3Dw5yDgcjdUnaDANJihtXpwaCiH3132989hRKSCsmfrFqin58WvzEnS5722Epk8UNRVfyToraczBP
