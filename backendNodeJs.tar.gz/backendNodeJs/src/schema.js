const paramsAddress = {
  type: 'object',
  properties: {
    addressId: { type: 'string' }
  }
};

const paramsTransaction = {
  type: 'object',
  properties: {
    transactionId: { type: 'string' }
  }
};

const address = {
  params: paramsAddress
};

const transaction = {
  params: paramsTransaction
};

const schemas = [address, transaction];

module.exports = schemas;
