//ver si cambio el nombre de los handlers
const addressValues = require('./addressValues');
const transactionValues = require('./transactionValues');
const schemas = require('./schema');

const address = {
  method: 'GET',
  url: '/address/:addressId',
  schema: schemas.address,
  handler: addressValues.getValues
};

const transaction = {
  method: 'GET',
  url: '/tx/:txId',
  schema: schemas.transaction,
  handler: transactionValues.getValues
};

const routes = [address, transaction];

module.exports = routes;
