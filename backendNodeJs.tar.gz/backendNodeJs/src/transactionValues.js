const axios = require('axios');

exports.getValues = async (req, reply) => {
  try {
    const { data } = await valuesFromApi(req.query.transactionId);
    reply.send(dataToSend(data));
  } catch (err) {
    console.error('Error en el handler', err);
  }
};

function valuesFromApi(transaction) {
  return axios.get(
    `https://cardanoexplorer.com/api/txs/summary/${transaction}`
  );
}

function dataToSend(data) {
  return {
    from: data.Right.ctsInputs.map(input => input[0]),
    to: data.Right.ctsOutputs.map(input => input[0])
  };
}

//http://localhost:3000/tx?transactionId=bb59a80039d06de9f5ea7f4311ccdf99386e0492a8360ca85ccdd348fe60b89a
